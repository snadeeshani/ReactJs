import React, {Component} from 'react';
import Menu from './Menu';
import Title from './Title';
import {ProductConsumer } from '../context';

export default class MenuList extends Component{
   
    render(){
      
        return(
            <React.Fragment>
                <div className="py-5">
                    <div className="container">
                        <Title name="our" title="Menu"/>
                        <div className="row">
                            <ProductConsumer>
                                {(value)=> {
                                       return value.products.map(product =>{
                                           return <Menu key={product.id} product={product} />;
                                       })
                                }}
                            </ProductConsumer>
                        </div>
                    </div>
                </div>
            </React.Fragment>
        );
    }
}