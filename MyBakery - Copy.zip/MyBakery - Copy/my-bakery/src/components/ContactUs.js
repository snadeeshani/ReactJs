import React, {Component} from 'react';

export default class ContactUs extends Component{

    render(){
        return(
            <div className= "container" style ={{marginTop: 10}}>
            
                <h3>Contact Us </h3>
                <br/>
                <form>
                    
                    <div className="form-group">
                        <label>Name:</label>
                        <input type="text" className="form-control"/>
                    </div>
                    <div className="form-group">
                        <label>Mobile Number:</label>
                        <input type="text" className="form-control"/>
                    </div>
                    <div className="form-group">
                        <label>Message:</label>
                        <input type="text" className="form-control"/>
                    </div>
                    <div className="form-group">
                        <input type="submit" value="Send" className="btn btn-info"/>
                    </div>
                    
                    
                </form>
                </div>
           
        )
    }
}