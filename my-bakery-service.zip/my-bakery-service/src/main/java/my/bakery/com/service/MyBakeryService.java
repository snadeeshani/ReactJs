package my.bakery.com.service;

import org.springframework.http.ResponseEntity;

public interface MyBakeryService {

        ResponseEntity fetchStoredProducts();

}
