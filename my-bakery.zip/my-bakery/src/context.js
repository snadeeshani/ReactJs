import React, {Component} from 'react';
import {storeProducts, detailProduct} from './data';

const ProductContext= React.createContext();


class ProductProvider extends Component{
    state={
        products: [],
        detailProduct: detailProduct,
        cart: [],
        modalOpen: false,
        modalProduct: detailProduct,
        cartSubTotal: 0,
        cartTax: 0,
        cartTotal: 0
    };
    /*To get values of object (not references) */
    componentDidMount(){
        this.storeProducts();
    }
    /* To assign the values in data.js */
    storeProducts = () =>{
        let tempProduct = [];
        storeProducts.forEach(item => {
            const singleItem= {...item};
            tempProduct = [...tempProduct, singleItem];
        });
        this.setState(()=>{
            return{products: tempProduct};
        });
    };
    getItem = (id) =>{
        const product = this.state.products.find(item => item.id ===id);
        return product;
    }
    /* catch the return object from getItem */
    handleDetail = (id) =>{
       const product = this.getItem(id);
       this.setState(() => {
           return {detailProduct: product}
       })

        
    };
    addToCart = (id) =>{
        let tempProduct = [...this.state.products];
        const index = tempProduct.indexOf(this.getItem(id));
        const product = tempProduct[index];
        product.inCart = true;
        product.count = 1;
        const price = product.price;
        product.total =price;

        this.setState(() => {
            return {products :tempProduct, cart:[...this.state.cart, product]};    
        }, ()=> {console.log(this.state)});
    };
    /**For menu popup window*/
    openModel = id =>{
        const product = this.getItem(id);
        this.setState(()=>{
            return {modalProduct: product, modalOpen:true}
        })
    }
    /*To close the popup window */
    closeModal = () =>{
        this.setState(() =>{
            return {modalOpen:false}
        })
    }
    /* For increase the number of quantity */
    increment = (id) => {
        console.log('This is increment method');
    }
     /* For reduce the number of quantity */
     decrement = (id) => {
        console.log('This is increment method2');
    }

    /*For remove the item */
    removeItem = (id) =>{
        console.log("Removed");
    }

    /*For clear the cart*/
    clearCart = () =>{
        console.log("cart cleared");
    }
    render(){
        return(
            <ProductContext.Provider value={{
                    ...this.state,
                    handleDetail: this.handleDetail,
                    addToCart: this.addToCart,
                    openModal: this.openModel,
                    closeModal:this.closeModal,
                    increment: this.increment,
                    decrement: this.decrement,
                    removeItem:this.removeItem,
                    clearcart: this.clearCart
            }}>
                {/* <button onClick={this.tester}>test me</button> */}
                {this.props.children}
            </ProductContext.Provider>
        );
    }
}

const ProductConsumer = ProductContext.Consumer;

export {ProductProvider, ProductConsumer};