import React, {Component} from 'react';
import Title from '../Title';
import CartColumns from './CartColumns';
import EmptyCart from './EmptyCart';
import {ProductConsumer} from '../../context';

export default class Cart extends Component{
    render(){
        return(
           <section>
               <ProductConsumer>
                   {value =>{
                       const {Cart} = value;
                    //    if(Cart.length > 0) {
                    //        return(
                    //            <React.Fragment>
                    //                <Title name="your" title="cart"></Title>
                    //                 <CartColumns/>
                    //            </React.Fragment>
                            
                    //        );
                    //    } else{
                    //     return <EmptyCart/>
                    //    }
                   }}
               </ProductConsumer>
              
               
           </section>
        );
    }
}